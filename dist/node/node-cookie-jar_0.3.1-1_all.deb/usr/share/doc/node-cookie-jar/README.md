cookie-jar
==========

Cookie Jar. Originally pulled from LearnBoost/tobi, maintained as vendor in request, now a standalone module.
